(function( jStat, Math ) {

var slice = [].slice,
	isNumber = jStat.utils.isNumber;

// flag==true denotes use of sample standard deviation
// Z Statistics
jStat.extend({
	// 2 different parameter lists:
	// ( value, mean, sd )
	// ( value, array, flag )
	zscore : function() {
		var args = slice.call( arguments );
		if ( isNumber( args[1] )) {
			return ( args[0] - args[1] ) / args[2];
		}
		return ( args[0] - jStat.mean( args[1] )) / jStat.stdev( args[1], args[2] );
	},

	// 3 different paramter lists:
	// ( value, mean, sd, sides )
	// ( zscore, sides )
	// ( value, array, sides, flag )
	ztest : function() {
		var args = slice.call( arguments );
		if ( args.length === 4 ) {
			if( isNumber( args[1] )) {
			var z = jStat.zscore(args[0],args[1],args[2])
				return ( args[3] === 1 ) ?
					(jStat.normal.cdf( -Math.abs(z),0,1)) :
				(jStat.normal.cdf( -Math.abs(z),0,1)* 2);
			}
			var z = args[0]
			return ( args[2] === 1 ) ?
				( jStat.normal.cdf( -Math.abs(z),0,1)) :
			(jStat.normal.cdf( -Math.abs(z),0,1)*2);
		}
		var z = jStat.zscore(args[0],args[1],args[3])
		return ( args[1] === 1 ) ?
			( jStat.normal.cdf( -Math.abs(z), 0, 1 )) :
		(jStat.normal.cdf( -Math.abs(z), 0, 1 )*2);
	}
});

jStat.extend( jStat.fn, {
	zscore : function( value, flag ) {
		return ( value - this.mean()) / this.stdev( flag );
	},

	ztest : function( value, sides, flag ) {
		var zscore = Math.abs( this.zscore( value, flag ));
		return ( sides === 1 ) ?
			( jStat.normal.cdf( -zscore, 0, 1 )) :
		(jStat.normal.cdf( -zscore, 0, 1 ) * 2);
	}
});

// T Statistics
jStat.extend({
	// 2 parameter lists
	// ( value, mean, sd, n )
	// ( value, array )
	tscore : function() {
		var args = slice.call( arguments );
		return ( args.length === 4 ) ?
			(( args[0] - args[1] ) / ( args[2] / Math.sqrt( args[3] ))) :
		(( args[0] - jStat.mean( args[1] )) / ( jStat.stdev( args[1], true ) / Math.sqrt( args[1].length )));
	},

	// 3 different paramter lists:
	// ( value, mean, sd, n, sides )
	// ( tscore, n, sides )
	// ( value, array, sides )
	ttest : function() {
		var args = slice.call( arguments );
		var tscore;
		if ( args.length === 5 ) {
			tscore = Math.abs( jStat.tscore( args[0], args[1], args[2], args[3] ));
			return ( args[4] === 1 ) ?
				(jStat.studentt.cdf( -tscore, args[3]-1 )) :
			(jStat.studentt.cdf( -tscore, args[3]-1)*2);
		}
		if ( isNumber( args[1] )) {
			tscore = Math.abs( args[0] )
			return ( args[2] == 1 ) ?
				( jStat.studentt.cdf( -tscore, args[1]-1)) :
			(jStat.studentt.cdf( -tscore, args[1]-1) * 2);
		}
		tscore = Math.abs( jStat.tscore( args[0], args[1] ))
		return ( args[2] == 1 ) ?
			( jStat.studentt.cdf( -tscore, args[1].length-1)) :
		(jStat.studentt.cdf( -tscore, args[1].length-1) * 2);
	}
});

jStat.extend( jStat.fn, {
	tscore : function( value ) {
		return ( value - this.mean()) / ( this.stdev( true ) / Math.sqrt( this.cols()));
	},

	ttest : function( value, sides ) {
		return ( sides === 1 ) ?
			( 1 - jStat.studentt.cdf( Math.abs( this.tscore(value)), this.cols()-1)) :
		(jStat.studentt.cdf( -Math.abs( this.tscore(value)), this.cols()-1)*2);
	}
});

// F Statistics
jStat.extend({
	// Paramter list is as follows:
	// ( array1, array2, array3, ... )
	// or it is an array of arrays
	// array of arrays conversion
	anovafscore : function() {
		var args = slice.call( arguments ),
			expVar, sample, sampMean, sampSampMean, tmpargs, unexpVar, i, j;
		if ( args.length === 1 ) {
			tmpargs = new Array( args[0].length );
			for ( i = 0; i < args[0].length; i++ ) {
				tmpargs[i] = args[0][i];
			}
			args = tmpargs;
		}
		// 2 sample case
		if ( args.length === 2 ) {
			return jStat.variance( args[0] ) / jStat.variance( args[1] );
		}
		// Builds sample array
		sample = new Array();
		for ( i = 0; i < args.length; i++ ) {
			sample = sample.concat( args[i] );
		}	
		sampMean = jStat.mean( sample );
		// Computes the explained variance
		expVar = 0;
		for ( i = 0; i < args.length; i++ ) {
			expVar = expVar + args[i].length * Math.pow( jStat.mean( args[i] ) - sampMean, 2 );
		}
		expVar /= ( args.length - 1 );
		// Computes unexplained variance
		unexpVar = 0;
		for ( i = 0; i < args.length; i++ ) {
			sampSampMean = jStat.mean( args[i] );
			for ( j = 0; j < args[i].length; j++ ) {
				unexpVar += Math.pow( args[i][j] - sampSampMean, 2 );
			}
		}
		unexpVar /= ( sample.length - args.length );
		return expVar / unexpVar;
	},

	// 2 different paramter setups
	// ( array1, array2, array3, ... )
	// ( anovafscore, df1, df2 )
	anovaftest : function() {
		var args = slice.call( arguments ),
			df1, df2, n, i;
		if ( isNumber( args[0] )) {
			return 1 - jStat.centralF.cdf( args[0], args[1], args[2] );
		}
		anovafscore = jStat.anovafscore( args );
		df1 = args.length - 1;
		n = 0;
		for ( i = 0; i < args.length; i++ ) {
			n = n + args[i].length;
		}
		df2 = n - df1 - 1;
		return 1 - jStat.centralF.cdf( anovafscore, df1, df2 );
	},

	ftest : function( fscore, df1, df2 ) {
		return 1 - jStat.centralF.cdf( fscore, df1, df2 );
	}
});

jStat.extend( jStat.fn, {
	anovafscore : function() {
		return jStat.anovafscore( this.toArray());
	},

	anovaftest: function() {
		var n = 0,
			i;
		for ( i = 0; i < this.length; i++ ) {
			n = n + this[i].length;
		}
		return jStat.ftest( this.anovafscore(), this.length - 1, n - this.length );
	}
});

// Error Bounds
jStat.extend({
	// 2 different parameter setups
	// ( value, alpha, sd, n )
	// ( value, alpha, array )
	normalci : function() {
		var args = slice.call( arguments ),
			ans = new Array(2),
			change;
		if ( args.length === 4 ) {
			change = Math.abs( jStat.normal.inv( args[1] / 2, 0, 1 ) * args[2] / Math.sqrt( args[3] ));
		} else {
			change = Math.abs( jStat.normal.inv( args[1] / 2, 0, 1 ) * jStat.stdev( args[2] ) / Math.sqrt( args[2].length ));
		}
		ans[0] = args[0] - change;
		ans[1] = args[0] + change;
		return ans;
	},

	// 2 different parameter setups
	// ( value, alpha, sd, n )
	// ( value, alpha, array )
	tci : function() {
		var args = slice.call( arguments ),
			ans = new Array(2),
			change;
		if ( args.length === 4 ) {
			change = Math.abs( jStat.studentt.inv( args[1] / 2, args[3] - 1 ) * args[2] / Math.sqrt( args[3] ));
		} else {
			change = Math.abs( jStat.studentt.inv( args[1] / 2, args[2].length ) * jStat.stdev( args[2], true ) / Math.sqrt( args[2].length ));
		}
		ans[0] = args[0] - change;
		ans[1] = args[0] + change;
		return ans;
	},

	significant : function( pvalue, alpha ) {
		return pvalue < alpha;
	}
});

jStat.extend( jStat.fn, {
	normalci : function( value, alpha ) {
		return jStat.normalci( value, alpha, this.toArray());
	},

	tci : function( value, alpha ) {
		return jStat.tci( value, alpha, this.toArray());
	}
});

}( this.jStat, Math ));
